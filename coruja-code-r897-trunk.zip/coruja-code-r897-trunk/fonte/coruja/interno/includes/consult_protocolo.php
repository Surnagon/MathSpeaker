<?

	 if ($_POST["tipo"]==1) {

																	
		include "view/protocolo/consulta_nome.php";
							
	 }	
	 
	  if ($_POST["tipo"]==2)
		 {
															
		include "view/protocolo/consulta_protocolo.php";
							
	 }	



?>