<?

	 if ($_POST["tipo"]==1) {

		include "view/carteirinhas/consulta_todos.php";
							
		 }
	 if ($_POST["tipo"]==2)
		 {
															
		include "view/carteirinhas/consulta_nome.php";
							
	 }	
	 
	  if ($_POST["tipo"]==3)
		 {
															
		include "view/carteirinhas/consulta_mat.php";
							
	 }	



?>