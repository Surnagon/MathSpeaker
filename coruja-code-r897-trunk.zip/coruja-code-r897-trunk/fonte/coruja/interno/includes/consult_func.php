<?

	 if ($_POST["tipo"]==1) {

		include "view/funcionarios/consulta_mat.php";
							
		 }
	 if ($_POST["tipo"]==2)
		 {
															
		include "view/funcionarios/consulta_nome.php";
							
	 }	


?>