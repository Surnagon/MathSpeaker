<?

	 if ($_POST["tipo"]==1) {

		include "view/reajuste_cargos_niveis/consulta_todos.php";
							
		 }
	 if ($_POST["tipo"]==2)
		 {
															
		include "view/reajuste_cargos_niveis/consulta_especifico.php";
							
	 }	


?>