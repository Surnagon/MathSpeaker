<?

	 if ($_POST["tipo"]==1) {

		include "view/averbacao/consulta_editar_mat.php";
							
		 }
	 if ($_POST["tipo"]==2)
		 {
															
		include "view/averbacao/consulta_editar_nome.php";
							
	 }	


?>