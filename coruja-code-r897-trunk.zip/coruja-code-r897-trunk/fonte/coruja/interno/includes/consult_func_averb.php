<?

	 if ($_POST["tipo"]==1) {

		include "view/averbacao/consulta_mat.php";
							
		 }
	 if ($_POST["tipo"]==2)
		 {
															
		include "view/averbacao/consulta_nome.php";
							
	 }	


?>