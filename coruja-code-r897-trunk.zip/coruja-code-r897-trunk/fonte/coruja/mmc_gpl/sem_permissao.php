<?php
    require_once("$BASE_DIR/includes/topo.php");
    require_once("$BASE_DIR/includes/menu_horizontal.php");
?>
<p align="center">
    Voc&ecirc; n&atilde;o tem permiss&atilde;o para utilizar esta fun&ccedil;&atilde;o.
</p>
<?php
    require_once("$BASE_DIR/includes/rodape.php");
    exit;
?>
