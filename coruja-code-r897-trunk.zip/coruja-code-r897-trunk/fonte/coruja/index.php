<?php
    header("Location: /coruja/autenticar/login_controle.php");
