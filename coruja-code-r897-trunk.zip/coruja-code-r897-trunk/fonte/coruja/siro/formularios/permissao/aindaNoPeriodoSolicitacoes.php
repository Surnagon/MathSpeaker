<p align="center">
    O per&iacute;odo para solicita&ccedil;&atilde;o e exclus&atilde;o de inscri&ccedil;&atilde;o ainda n&atilde;o est&aacute; encerrado.<br/>
    Espere pelo t&eacute;rmino das solicita&ccedil;&otilde;es de inscri&ccedil;&otilde;es para fazer a an&aacute;lise.
</p>