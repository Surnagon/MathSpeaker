<p align="center">
    A sua atual situa&ccedil;&atilde;o de matr&iacute;cula impede o seu acesso a esta funcionalidade.
    <br/>
    Dirija-se &agrave; secretaria e informe a situa&ccedil;&atilde;o.
</p>
