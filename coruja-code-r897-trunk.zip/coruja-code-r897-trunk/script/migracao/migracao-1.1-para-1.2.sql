alter table Aluno add estabCursoOrigemCidade varchar(40) NOT NULL default 'RIO DE JANEIRO' after estabCursoOrigem;
